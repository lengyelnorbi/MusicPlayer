import { getEndpoint } from '@/services/apiConfig';
import { loadStoredSession } from '@/services/auth';
import { saveDownloadedTrack } from '@/services/offlineLibrary';
import type { Music } from '@/types/music';

/**
 * Contract expected from ASP.NET: GET /api/music/{id}/download-url returns
 * { driveFileId, downloadUrl } for an authorized file. The download URL must be
 * short-lived and authorized. Adjust this adapter to match your real controller.
 */
export async function downloadDriveTrack(track: Music) {
  const session = await loadStoredSession();
  if (!session?.accessToken) throw new Error('Sign in online before downloading music.');
  const response = await fetch(getEndpoint(`/api/music/${track.id}/download-url`), {
    headers: { Authorization: `Bearer ${session.accessToken}` },
  });
  if (!response.ok) throw new Error(`Could not get Google Drive download URL (HTTP ${response.status}).`);
  const payload = await response.json() as { driveFileId?: string; downloadUrl?: string; url?: string };
  const downloadUrl = payload.downloadUrl ?? payload.url;
  if (!downloadUrl) throw new Error('The backend response did not contain downloadUrl.');
  const driveFileId = payload.driveFileId ?? String((track as any).file_id ?? track.id);
  return saveDownloadedTrack(
  {
    ...track,
    genre: track.genre ?? null,
  },
  downloadUrl,
  session.accessToken ?? undefined,
);
}
