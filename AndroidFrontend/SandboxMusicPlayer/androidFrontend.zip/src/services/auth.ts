import * as SecureStore from 'expo-secure-store';
import { getEndpoint } from '@/services/apiConfig';

const ACCESS_TOKEN_KEY = 'music_app_access_token';
const REFRESH_TOKEN_KEY = 'music_app_refresh_token';
const USER_KEY = 'music_app_user';

export type AuthUser = {
  id?: number | string;
  ID?: number | string;
  username?: string;
  Username?: string;
  email?: string;
  Email?: string;
  [key: string]: unknown;
};

export type StoredSession = {
  accessToken: string;
  refreshToken?: string;
  user?: AuthUser;
  savedAt: string;
};

/**
 * Adjust LOGIN_PATH and the request/response mapping below to match your API.
 * Tokens are stored using the phone's secure storage, not AsyncStorage.
 */
const LOGIN_PATH = '/api/auth/mobile';

type LoginResponse = {
  success?: boolean;
  expiresIn?: number;
  refreshTokenExpiresIn?: number;
  accessToken?: string;
  access_token?: string;
  token?: string;
  refreshToken?: string;
  refresh_token?: string;
  user?: AuthUser;
  [key: string]: unknown;
};

export async function loginWithPassword(emailOrUsername: string, password: string): Promise<StoredSession> {
  const response = await fetch(getEndpoint(LOGIN_PATH), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ email: emailOrUsername.trim(), password, source: 'user' }),
  });

  const body = (await response.json().catch(() => ({}))) as LoginResponse;
  if (!response.ok) {
    const message = typeof body.message === 'string'
      ? body.message
      : typeof body.title === 'string'
        ? body.title
        : `Login failed (${response.status}). Check the API login route and credentials.`;
    throw new Error(message);
  }

  const accessToken = body.accessToken ?? body.access_token ?? body.token;
  if (!accessToken || typeof accessToken !== 'string') {
    throw new Error('The API authenticated without returning an access token. Apply the native-client response change in backend/AuthController.native-response.patch.txt, then try again.');
  }

  const refreshToken = body.refreshToken ?? body.refresh_token;
  const user = body.user ?? undefined;
  const session: StoredSession = {
    accessToken,
    ...(typeof refreshToken === 'string' ? { refreshToken } : {}),
    ...(user ? { user } : {}),
    savedAt: new Date().toISOString(),
  };
  await saveSession(session);
  return session;
}

export async function saveSession(session: StoredSession): Promise<void> {
  await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, session.accessToken);
  if (session.refreshToken) await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, session.refreshToken);
  else await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
  if (session.user) await SecureStore.setItemAsync(USER_KEY, JSON.stringify(session.user));
  else await SecureStore.deleteItemAsync(USER_KEY);
}

export async function loadStoredSession(): Promise<StoredSession | null> {
  const accessToken = await SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
  if (!accessToken) return null;
  const [refreshToken, userJson] = await Promise.all([
    SecureStore.getItemAsync(REFRESH_TOKEN_KEY),
    SecureStore.getItemAsync(USER_KEY),
  ]);
  let user: AuthUser | undefined;
  try { user = userJson ? JSON.parse(userJson) as AuthUser : undefined; } catch { user = undefined; }
  return {
    accessToken,
    ...(refreshToken ? { refreshToken } : {}),
    ...(user ? { user } : {}),
    savedAt: 'previously saved',
  };
}

export async function clearStoredSession(): Promise<void> {
  await Promise.all([
    SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY),
    SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY),
    SecureStore.deleteItemAsync(USER_KEY),
  ]);
}
