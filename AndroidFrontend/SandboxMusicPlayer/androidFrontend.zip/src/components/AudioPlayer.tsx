import React, { useEffect } from "react";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";

type AudioPlayerProps = {
  url: string | null;
  onError?: (error: unknown) => void;
};

export default function AudioPlayer({
  url,
  onError,
}: AudioPlayerProps) {
  const player = useAudioPlayer(null);
  const status = useAudioPlayerStatus(player);

  useEffect(() => {
    if (!url) {
      console.log("[AudioPlayer] No stream URL received.");
      return;
    }

    let cancelled = false;

    const startPlayback = async () => {
      try {
        console.log("[AudioPlayer] Loading URL:", url);

        await player.replace({ uri: url });

        if (cancelled) return;

        player.play();
        console.log("[AudioPlayer] Play requested.");
      } catch (error) {
        console.error("[AudioPlayer] Failed to load stream:", error);
        onError?.(error);
      }
    };

    void startPlayback();

    return () => {
      cancelled = true;
    };
  }, [url, player, onError]);

  useEffect(() => {
    console.log("[AudioPlayer] Status:", {
      isLoaded: status.isLoaded,
      playing: status.playing,
      isBuffering: status.isBuffering,
      error: status.error,
    });

    if (status.error) {
      onError?.(new Error(status.error));
    }
  }, [status.isLoaded, status.playing, status.isBuffering, status.error, onError]);

  return null;
}