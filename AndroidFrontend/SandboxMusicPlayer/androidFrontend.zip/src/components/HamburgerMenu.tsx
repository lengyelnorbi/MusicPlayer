import React from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { useMusicApp } from '@/context/MusicAppContext';

export function HamburgerButton() {
  const { menuOpen, setMenuOpen, mode } = useMusicApp();
  return <Pressable accessibilityRole="button" accessibilityLabel="Open navigation menu" onPress={() => setMenuOpen(!menuOpen)} style={styles.hamburger}>
    <Text style={styles.hamburgerText}>{menuOpen ? '×' : '☰'}</Text>
    <Text style={styles.modePill}>{mode === 'online' ? 'ONLINE' : 'OFFLINE'}</Text>
  </Pressable>;
}
export function HamburgerMenu({ onLogin }: { onLogin: () => void }) {
  const { menuOpen, setMenuOpen, mode, setMode, session, logout, initializeOffline } = useMusicApp();
  return <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
    <View style={styles.overlay}>
      <Pressable style={styles.scrim} onPress={() => setMenuOpen(false)} />
      <View style={styles.drawer}>
        <Text style={styles.heading}>Music library</Text>
        <Text style={styles.subheading}>{session?.user?.username ?? session?.user?.Username ?? 'Not signed in'}</Text>
        <View style={styles.separator} />
        <Text style={styles.section}>LIBRARY MODE</Text>
        <Pressable style={[styles.item, mode === 'online' && styles.selected]} onPress={() => void setMode('online')}><Text style={styles.itemText}>☁  Online library</Text></Pressable>
        <Pressable style={[styles.item, mode === 'offline' && styles.selected]} onPress={() => void setMode('offline').catch(e => console.warn('Offline setup failed', e))}><Text style={styles.itemText}>♫  Offline library</Text></Pressable>
        <Pressable style={styles.item} onPress={() => void initializeOffline().catch(e => console.warn('Offline setup failed', e))}><Text style={styles.itemText}>▣  Initialize offline library</Text></Pressable>
        <View style={styles.separator} />
        {session ? <Pressable style={styles.item} onPress={() => { void logout(); setMenuOpen(false); }}><Text style={styles.itemText}>↪  Log out</Text></Pressable> : <Pressable style={styles.item} onPress={() => { setMenuOpen(false); onLogin(); }}><Text style={styles.itemText}>⇥  Login</Text></Pressable>}
        <Pressable style={styles.close} onPress={() => setMenuOpen(false)}><Text style={styles.closeText}>Close menu</Text></Pressable>
      </View>
    </View>
  </Modal>;
}
const styles = StyleSheet.create({
  hamburger: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 14, paddingVertical: 10, alignSelf: 'flex-start' },
  hamburgerText: { color: '#fff', fontSize: 25, fontWeight: '700' }, modePill: { color: '#c4b5fd', fontSize: 10, fontWeight: '900', letterSpacing: 1 },
  overlay: { flex: 1, flexDirection: 'row', backgroundColor: 'rgba(0,0,0,0.45)' }, scrim: { flex: 1 },
  drawer: { width: 290, maxWidth: '86%', backgroundColor: '#10101b', paddingTop: 58, paddingHorizontal: 18, borderLeftWidth: 1, borderColor: '#302943' },
  heading: { color: '#fff', fontSize: 24, fontWeight: '900' }, subheading: { color: '#aaa7bd', marginTop: 6, marginBottom: 18 }, separator: { height: 1, backgroundColor: '#302943', marginVertical: 16 },
  section: { color: '#a78bfa', fontSize: 11, fontWeight: '900', letterSpacing: 1.5, marginBottom: 8 },
  item: { paddingVertical: 14, paddingHorizontal: 12, borderRadius: 12 }, selected: { backgroundColor: '#302044' }, itemText: { color: '#f4f0ff', fontSize: 15, fontWeight: '600' },
  close: { marginTop: 'auto', marginBottom: 32, alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: '#272039' }, closeText: { color: '#ddd6fe', fontWeight: '800' },
});
