import React from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { styles } from "@/styles/styles";
type Props = { url: string; onChangeUrl: (v: string) => void; loading: boolean; message: string; canSubmit: boolean; onSubmit: () => void };
export function MusicRequestPanel({ url, onChangeUrl, loading, message, canSubmit, onSubmit }: Props) {
  return <View style={styles.requestPanel}>
    <Text style={styles.requestTitle}>Request a music upload</Text>
    <Text style={styles.hint}>Send a YouTube URL and the administrator can add it to the library.</Text>
    <TextInput value={url} onChangeText={onChangeUrl} placeholder="https://www.youtube.com/watch?v=..." placeholderTextColor="#526887" autoCapitalize="none" keyboardType="url" style={styles.input} />
    <Pressable disabled={loading || !url.trim() || !canSubmit} style={styles.primaryButton} onPress={onSubmit}><Text style={styles.buttonText}>{loading ? "Sending..." : "Send request"}</Text></Pressable>
    {!!message && <Text style={styles.pinkText}>{message}</Text>}
  </View>;
}
