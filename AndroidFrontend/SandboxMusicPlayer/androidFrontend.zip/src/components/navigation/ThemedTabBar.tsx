import React from 'react';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';

const icons: Record<string, string> = { index: '♫', playlists: '☷' };

export function ThemedTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  return (
    <View style={styles.outer}>
      <View style={styles.bar}>
        {state.routes.map((route, index) => {
          const { options } = descriptors[route.key];
          const label = typeof options.tabBarLabel === 'string' ? options.tabBarLabel : options.title ?? route.name;
          const focused = state.index === index;
          const onPress = () => {
            const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
            if (!focused && !event.defaultPrevented) navigation.navigate(route.name, route.params);
          };
          const onLongPress = () => navigation.emit({ type: 'tabLongPress', target: route.key });
          return (
            <Pressable key={route.key} accessibilityRole="tab" accessibilityState={focused ? { selected: true } : {}} accessibilityLabel={options.tabBarAccessibilityLabel} onPress={onPress} onLongPress={onLongPress} style={styles.tab}>
              <View style={[styles.activePill, focused && styles.activePillSelected]}>
                <Text style={[styles.icon, focused && styles.iconSelected]}>{icons[route.name] ?? '•'}</Text>
                <Text style={[styles.label, focused && styles.labelSelected]}>{label}</Text>
              </View>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: { backgroundColor: '#0b0b12', borderTopWidth: 1, borderTopColor: '#252033', paddingHorizontal: 18, paddingTop: 10, paddingBottom: Platform.OS === 'ios' ? 6 : 10 },
  bar: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#14131d', borderRadius: 22, padding: 5, borderWidth: 1, borderColor: '#292437' },
  tab: { flex: 1 }, activePill: { minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, borderRadius: 17, paddingHorizontal: 12, backgroundColor: 'transparent' },
  activePillSelected: { backgroundColor: '#6d28d9', borderWidth: 1, borderColor: '#a78bfa', shadowColor: '#8b5cf6', shadowOpacity: 0.3, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 5 },
  icon: { color: '#858397', fontSize: 23, fontWeight: '800' }, iconSelected: { color: '#fff' }, label: { color: '#858397', fontSize: 13, fontWeight: '700' }, labelSelected: { color: '#fff', fontWeight: '900' },
});
