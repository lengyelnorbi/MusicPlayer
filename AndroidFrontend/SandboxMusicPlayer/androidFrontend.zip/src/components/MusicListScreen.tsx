import React, { useState } from "react";
import { ActivityIndicator, FlatList, SafeAreaView, ScrollView, Text, View } from "react-native";
import type { Music } from "@/types/music";
import { addMusicToPlaylist, removeMusicFromPlaylist } from "../services/musicService";
import { createPlaylist } from "../services/playlistService";
import { GenreFilter } from "@/components/GenreFilter";
import { MusicCard } from "@/components/MusicCard";
import { MusicPagination } from "@/components/MusicPagination";
import { MusicRequestPanel } from "@/components/MusicRequestPanel";
import { MusicSearch } from "@/components/MusicSearch";
import { PlaylistModal } from "@/components/PlaylistModal";
import { useMusicList } from "@/components/useMusicList";
import { styles } from "@/styles/styles";
import type { MusicMode } from "@/services/appPreferences";
import { getOfflineTrackUri } from "@/services/offlineLibrary";
import { downloadDriveTrack } from "@/services/driveService";

type Props = {
  mode?: MusicMode;
  loggedIn?: boolean; onPlayMusic?: (music: Music, currentList: Music[]) => void;
  onRequestMusic?: (youtubeUrl: string) => Promise<void>;
  onDownloadMusic?: (musicID: number, url: string) => void;
  onAddToFavorites?: (musicID: number) => void;
};
export default function MusicListScreen({ mode = "online", loggedIn = false, onPlayMusic, onRequestMusic, onDownloadMusic, onAddToFavorites }: Props) {
  const music = useMusicList(mode);
  const [activeMusicId, setActiveMusicId] = useState<number | null>(null);
  const [openMenuId, setOpenMenuId] = useState<number | null>(null);
  const [showPlaylistOverlay, setShowPlaylistOverlay] = useState(false);
  const [selectedMusicID, setSelectedMusicID] = useState<number | null>(null);
  const [selectedPlaylistIds, setSelectedPlaylistIds] = useState<number[]>([]);
  const [showNewPlaylistInput, setShowNewPlaylistInput] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [requestUrl, setRequestUrl] = useState("");
  const [requestLoading, setRequestLoading] = useState(false);
  const [requestMessage, setRequestMessage] = useState("");

  const openSaveOverlay = (item: Music) => {
    setSelectedMusicID(item.id); setSelectedPlaylistIds(item.playlistIDs ?? []);
    setOpenMenuId(null); setShowPlaylistOverlay(true);
  };
  const closeOverlay = () => {
    setShowPlaylistOverlay(false); setSelectedMusicID(null); setShowNewPlaylistInput(false); setNewPlaylistName("");
  };
  const togglePlaylist = async (playlistID: number) => {
    if (selectedMusicID == null) return;
    const selected = selectedPlaylistIds.includes(playlistID);
    try {
      const ok = selected ? await removeMusicFromPlaylist(playlistID, selectedMusicID) : await addMusicToPlaylist(playlistID, selectedMusicID);
      if (!ok) throw new Error("Playlist update failed");
      setSelectedPlaylistIds(ids => selected ? ids.filter(id => id !== playlistID) : [...new Set([...ids, playlistID])]);
    } catch (error) { console.error("Could not update playlist:", error); }
  };
  const submitPlaylist = async () => {
    const name = newPlaylistName.trim(); if (!name) return;
    try {
      await createPlaylist(name); setNewPlaylistName(""); setShowNewPlaylistInput(false); await music.loadMusic();
    } catch (error) { console.error("Could not create playlist:", error); }
  };
  const submitRequest = async () => {
    if (!loggedIn || !requestUrl.trim() || !onRequestMusic) return;
    setRequestLoading(true); setRequestMessage("");
    try {
      await onRequestMusic(requestUrl.trim()); setRequestUrl(""); setRequestMessage("Music request sent to the administrator.");
    } catch { setRequestMessage("Could not send the music request."); }
    finally { setRequestLoading(false); }
  };
  const handleDownload = async (item: Music) => {
    setOpenMenuId(null);
    try {
      if (mode === "offline") {
        console.info("This track is already in the offline library.");
        return;
      }
      const saved = await downloadDriveTrack(item);
      onDownloadMusic?.(item.id, saved.fileUri);
      await music.loadMusic();
    } catch (error) { console.error("Could not download track:", error); }
  };

  return <SafeAreaView style={styles.safeArea}>
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent} keyboardShouldPersistTaps="handled">
      <Text style={styles.muted}>{mode === "online" ? "Online catalogue · downloads saved for offline listening" : "Offline library · downloaded files only"}</Text>
      <View style={styles.searchPanel}>
        <MusicSearch value={music.searchTerm} onChangeText={music.setSearchTerm} onClear={music.clearFilters} showClear={!!music.searchTerm || music.selectedGenres.length > 0} />
        <GenreFilter genres={music.availableGenres} selectedGenres={music.selectedGenres} onToggle={music.toggleGenre} />
      </View>
      {mode === "online" && loggedIn && <MusicRequestPanel url={requestUrl} onChangeUrl={setRequestUrl} loading={requestLoading} message={requestMessage} canSubmit={!!onRequestMusic} onSubmit={submitRequest} />}
      <View style={styles.listHeader}>
        <Text style={styles.muted}>{music.maxItemCount} tracks</Text><Text style={styles.muted}>Per page:</Text>
        <View style={styles.limitRow}>{[10, 25, 50, 75, 100].map(n =>
          <Text key={n} onPress={() => music.changeLimit(n)} style={[styles.limitButton, music.limit === n && styles.pageActive, styles.pageText]}>{n}</Text>
        )}</View>
      </View>
      <MusicPagination currentPage={music.currentPage} maxPageCount={music.maxPageCount} onPageChange={music.setCurrentPage} />
      {music.loading && <ActivityIndicator color="#f472b6" style={{ marginVertical: 18 }} />}
      <FlatList data={music.musics} renderItem={({ item }) => <MusicCard
        item={item} active={activeMusicId === item.id} loggedIn={loggedIn} menuOpen={openMenuId === item.id}
        onPlay={async selected => {
          setActiveMusicId(selected.id); setOpenMenuId(null);
          if (mode === "offline") {
            const fileUri = await getOfflineTrackUri(selected.id);
            if (!fileUri) { console.warn("Local audio file is missing for track", selected.id); return; }
            onPlayMusic?.({ ...selected, fileUri }, music.musics);
          } else onPlayMusic?.(selected, music.musics);
        }}
        onToggleMenu={id => setOpenMenuId(openMenuId === id ? null : id)}
        onSaveToPlaylist={mode === "online" ? openSaveOverlay : undefined} onDownload={handleDownload}
        onFavorite={selected => { if (mode === "online") onAddToFavorites?.(selected.id); setOpenMenuId(null); }}
      />} keyExtractor={item => String(item.id)} scrollEnabled={false}
      ListEmptyComponent={!music.loading ? <Text style={styles.hint}>No music found.</Text> : null}
      ItemSeparatorComponent={() => <View style={{ height: 10 }} />} />
    </ScrollView>
    <PlaylistModal visible={showPlaylistOverlay} playlists={music.userPlaylists} selectedPlaylistIds={selectedPlaylistIds}
      showNewInput={showNewPlaylistInput} newPlaylistName={newPlaylistName} onClose={closeOverlay}
      onTogglePlaylist={togglePlaylist} onShowNewInput={() => setShowNewPlaylistInput(true)}
      onNewNameChange={setNewPlaylistName} onCancelNew={() => { setShowNewPlaylistInput(false); setNewPlaylistName(""); }}
      onCreate={submitPlaylist} />
  </SafeAreaView>;
}
