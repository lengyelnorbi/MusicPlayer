import { useCallback, useEffect, useState } from "react";
import type { Music } from "@/types/music";
import type { Playlist } from "@/types/playlist";
import { getMusicList } from "@/services/musicService";
import { getOfflineTracks } from "@/services/offlineLibrary";
import type { MusicMode } from "@/services/appPreferences";

export function useMusicList(mode: MusicMode = "online") {
  const [musics, setMusics] = useState<Music[]>([]);
  const [availableGenres, setAvailableGenres] = useState<string[]>([]);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [maxItemCount, setMaxItemCount] = useState(0);
  const [maxPageCount, setMaxPageCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [userPlaylists, setUserPlaylists] = useState<Playlist[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 2000);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const loadMusic = useCallback(async () => {
    setLoading(true);
    try {
      if (mode === "offline") {
        const local = await getOfflineTracks();
        const filtered = local.filter((item) =>
          item.title.toLowerCase().includes(debouncedSearch.toLowerCase()) &&
          (!selectedGenres.length || selectedGenres.includes(String(item.genre ?? "")))
        );
        const start = (currentPage - 1) * limit;
        setMusics(filtered.slice(start, start + limit));
        setMaxItemCount(filtered.length);
        setMaxPageCount(Math.ceil(filtered.length / limit));
        setAvailableGenres([...new Set(local.map(item => item.genre).filter((g): g is string => !!g))]);
        setUserPlaylists([]);
      } else {
        const result = await getMusicList(currentPage, limit, debouncedSearch, selectedGenres);
        setMusics(result.items ?? []);
        setMaxItemCount(result.totalItemCount ?? 0);
        setMaxPageCount(result.totalPages ?? 0);
        setAvailableGenres(result.availableGenres ?? []);
        setUserPlaylists(result.userPlaylists ?? []);
      }
    } catch (error) {
      console.error("Could not load music:", error);
    } finally {
      setLoading(false);
    }
  }, [currentPage, limit, debouncedSearch, selectedGenres, mode]);

  useEffect(() => { void loadMusic(); }, [loadMusic]);

  const toggleGenre = (genre: string) => {
    setSelectedGenres(old => old.includes(genre) ? old.filter(g => g !== genre) : [...old, genre]);
    setCurrentPage(1);
  };
  const clearFilters = () => {
    setSearchTerm(""); setDebouncedSearch(""); setSelectedGenres([]); setCurrentPage(1);
  };
  const changeLimit = (next: number) => { setLimit(next); setCurrentPage(1); };

  return {
    musics, availableGenres, selectedGenres, searchTerm, setSearchTerm,
    currentPage, setCurrentPage, limit, changeLimit, maxItemCount,
    maxPageCount, loading, userPlaylists, loadMusic, toggleGenre, clearFilters,
  };
}
