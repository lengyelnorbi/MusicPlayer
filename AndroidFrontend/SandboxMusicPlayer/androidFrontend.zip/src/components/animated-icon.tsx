import React from 'react';
import { View } from 'react-native';
/** Replace with your existing animated splash overlay component if you have one. */
export function AnimatedSplashOverlay() { return <View pointerEvents="none" />; }
