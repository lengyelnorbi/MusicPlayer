import { DarkTheme, DefaultTheme, ThemeProvider } from 'expo-router';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useColorScheme } from 'react-native';
import { useEffect } from 'react';
import { MusicAppProvider } from '@/context/MusicAppContext';
import { AnimatedSplashOverlay } from '../../extra_files/animated-icon';

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  const scheme = useColorScheme();
  useEffect(() => { const t = setTimeout(() => SplashScreen.hideAsync().catch(() => {}), 900); return () => clearTimeout(t); }, []);
  return (
    <ThemeProvider value={scheme === 'dark' ? DarkTheme : DefaultTheme}>
      <MusicAppProvider>
        <AnimatedSplashOverlay />
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: '#0b0b12' } }}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="login" options={{ presentation: 'modal' }} />
        </Stack>
      </MusicAppProvider>
    </ThemeProvider>
  );
}
