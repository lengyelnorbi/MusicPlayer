import React from 'react';
import MusicListScreen from '../../components/MusicListScreen';
import { useMusicApp } from '@/context/MusicAppContext';
import type { Music } from '@/types/music';
import { useRouter } from 'expo-router';
import { getOfflineTrackUri } from '@/services/offlineLibrary';
import { getEndpoint } from '@/services/apiConfig';

export default function MusicsRoute() {
  const { mode, session } = useMusicApp();
  const router = useRouter();

  const play = async (
    music: Music,
    currentList: Music[],
  ) => {
    try {
      let playbackUrl: string;

      if (mode === 'offline') {
        const localUri = await getOfflineTrackUri(music.id);

        if (!localUri) {
          console.warn('This song is not downloaded for offline playback.');
          return;
        }

        playbackUrl = localUri;
      } else {
        playbackUrl = getEndpoint(
          `/api/music/${music.id}/stream`,
        );
      }

      // TODO: Pass playbackUrl and currentList to your real AudioPlayer.
      console.info('Play requested', {
        title: music.title,
        playbackUrl,
        queueLength: currentList.length,
      });
    } catch (error) {
      console.error('Unable to start playback', error);
    }
  };

  return (
    <MusicListScreen
      mode={mode}
      loggedIn={!!session}
      onPlayMusic={play}
      onRequestMusic={async url => {
        // TODO: Implement the authenticated request handler.
        console.info('Music request:', url);
      }}
    />
  );
}
