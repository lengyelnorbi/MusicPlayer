import React, { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

type Playlist = { id: string; name: string; songs: number };
export default function PlaylistsScreen() {
  const [items, setItems] = useState<Playlist[]>([]);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  function create() {
    const value = name.trim();
    if (!value) { Alert.alert('Playlist name required', 'Enter a name first.'); return; }
    setItems(current => [...current, { id: `${Date.now()}`, name: value, songs: 0 }]);
    setName(''); setCreating(false);
  }
  return <View style={styles.root}>
    <View style={styles.heading}><View><Text style={styles.title}>Your playlists</Text><Text style={styles.subtitle}>Collections for every mood</Text></View><Pressable style={styles.add} onPress={() => setCreating(v => !v)}><Text style={styles.addText}>{creating ? 'Cancel' : '+ New'}</Text></Pressable></View>
    {creating && <View style={styles.form}><TextInput value={name} onChangeText={setName} placeholder="Playlist name" placeholderTextColor="#858397" style={styles.input} autoFocus returnKeyType="done" onSubmitEditing={create}/><Pressable style={styles.create} onPress={create}><Text style={styles.createText}>Create playlist</Text></Pressable></View>}
    <FlatList data={items} keyExtractor={item => item.id} contentContainerStyle={items.length ? styles.list : styles.emptyWrap} renderItem={({ item }) => <Pressable style={styles.card} onPress={() => Alert.alert(item.name, 'Playlist persistence and song membership are not connected yet.')}><View style={styles.art}><Text style={styles.artText}>♫</Text></View><View style={{ flex: 1 }}><Text style={styles.playlistName}>{item.name}</Text><Text style={styles.subtitle}>{item.songs} songs</Text></View><Text style={styles.chevron}>›</Text></Pressable>} ListEmptyComponent={<View style={styles.empty}><Text style={styles.emptyArt}>♫</Text><Text style={styles.emptyTitle}>No playlists yet</Text><Text style={styles.subtitle}>Create a playlist to collect songs you love.</Text><Pressable style={styles.create} onPress={() => setCreating(true)}><Text style={styles.createText}>Create your first playlist</Text></Pressable></View>} />
  </View>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#0b0b12', padding: 20 }, heading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }, title: { color: '#fff', fontSize: 27, fontWeight: '900' }, subtitle: { color: '#9996ab', fontSize: 13, marginTop: 5 }, add: { backgroundColor: '#7c3aed', paddingVertical: 11, paddingHorizontal: 15, borderRadius: 12 }, addText: { color: '#fff', fontWeight: '800' }, form: { backgroundColor: '#171622', padding: 14, borderRadius: 16, marginBottom: 18, gap: 10 }, input: { color: '#fff', backgroundColor: '#0b0b12', borderWidth: 1, borderColor: '#302943', padding: 13, borderRadius: 10 }, create: { backgroundColor: '#6d28d9', borderRadius: 12, paddingVertical: 13, paddingHorizontal: 16, alignItems: 'center', marginTop: 10 }, createText: { color: '#fff', fontWeight: '800' }, list: { gap: 12, paddingBottom: 20 }, card: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#171622', padding: 12, borderRadius: 16, borderWidth: 1, borderColor: '#252033' }, art: { width: 58, height: 58, backgroundColor: '#392957', borderRadius: 12, alignItems: 'center', justifyContent: 'center' }, artText: { color: '#ddd6fe', fontSize: 30 }, playlistName: { color: '#fff', fontSize: 16, fontWeight: '800' }, chevron: { color: '#9996ab', fontSize: 28 }, emptyWrap: { flexGrow: 1, justifyContent: 'center' }, empty: { alignItems: 'center', paddingHorizontal: 20 }, emptyArt: { color: '#c4b5fd', fontSize: 58, marginBottom: 14 }, emptyTitle: { color: '#fff', fontSize: 20, fontWeight: '900' } });
