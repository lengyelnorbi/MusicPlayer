import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { loadMusicMode, saveMusicMode, type MusicMode } from '@/services/appPreferences';
import { initializeOfflineLibrary } from '@/services/offlineLibrary';
import { clearStoredSession, loadStoredSession, type StoredSession } from '@/services/auth';

type ContextValue = {
  mode: MusicMode; setMode: (mode: MusicMode) => Promise<void>;
  menuOpen: boolean; setMenuOpen: (open: boolean) => void;
  session: StoredSession | null; refreshSession: () => Promise<void>; logout: () => Promise<void>;
  offlineReady: boolean; initializing: boolean; initializeOffline: () => Promise<void>;
};
const MusicAppContext = createContext<ContextValue | null>(null);
export function MusicAppProvider({ children }: React.PropsWithChildren) {
  const [mode, setModeState] = useState<MusicMode>('online');
  const [menuOpen, setMenuOpen] = useState(false);
  const [session, setSession] = useState<StoredSession | null>(null);
  const [offlineReady, setOfflineReady] = useState(false);
  const [initializing, setInitializing] = useState(true);
  useEffect(() => {
    Promise.all([loadMusicMode(), loadStoredSession()]).then(([savedMode, savedSession]) => {
      setModeState(savedMode); setSession(savedSession);
    }).catch(console.warn).finally(() => setInitializing(false));
  }, []);
  const setMode = useCallback(async (next: MusicMode) => {
    if (next === 'offline') {
      await initializeOfflineLibrary(); setOfflineReady(true);
    }
    await saveMusicMode(next); setModeState(next); setMenuOpen(false);
  }, []);
  const initializeOffline = useCallback(async () => { await initializeOfflineLibrary(); setOfflineReady(true); }, []);
  const refreshSession = useCallback(async () => setSession(await loadStoredSession()), []);
  const logout = useCallback(async () => { await clearStoredSession(); setSession(null); }, []);
  const value = useMemo(() => ({ mode, setMode, menuOpen, setMenuOpen, session, refreshSession, logout, offlineReady, initializing, initializeOffline }), [mode, setMode, menuOpen, session, refreshSession, logout, offlineReady, initializing, initializeOffline]);
  return <MusicAppContext.Provider value={value}>{children}</MusicAppContext.Provider>;
}
export function useMusicApp() { const value = useContext(MusicAppContext); if (!value) throw new Error('useMusicApp must be used inside MusicAppProvider'); return value; }
